feedback_data = {
'S_No': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
'Name': ['Ravi', 'Meera', 'Sam', 'Anu', 'Raj', 'Divya', 'Arjun', 'Kiran', 'Leela', 'Nisha'],
'Feedback': [
' Very GOOD Service!!!',
'poor support, not happy ',
'GREAT experience! will come again.',
'okay okay...',
' not BAD',
'Excellent care, excellent staff!',
'good food and good ambience!',
'Poor response and poor handling of issue',
'Satisfied. But could be better.',
'Good support... quick service.'
],
'Rating': [5, 2, 5, 3, 2, 5, 4, 1, 3, 4]
}
# Step 2: Add More Feedbacks

n = int(input("How many more feedbacks do you want to add? "))

for i in range(n):
    print(f"\nEnter details for feedback {i + 1}")

    name = input("Enter your name: ")
    feedback = input("Enter your written feedback: ")
    rating = int(input("Enter your rating (1-5): "))
 # Validate the rating
    while rating < 1 or rating > 5:
        print("Invalid rating! Please enter a rating between 1 and 5.")
        rating = int(input("Enter your rating (1-5): "))

    # Automatically generate serial number
    s_no = len(feedback_data['S_No']) + 1

    # Append new data to the dictionary
    feedback_data['S_No'].append(s_no)
    feedback_data['Name'].append(name)
    feedback_data['Feedback'].append(feedback)
    feedback_data['Rating'].append(rating)

print("\nFeedbacks added successfully!")
print(feedback_data)
# Step 3: Text Cleaning

for i in range(len(feedback_data['Feedback'])):
    text = feedback_data['Feedback'][i]

    # Remove punctuation
    text = text.replace('.', '')
    text = text.replace(',', '')
    text = text.replace('!', '')
    text = text.replace('?', '')

    # Remove extra spaces and leading/trailing spaces
    text = ' '.join(text.split())

    # Remove leading and trailing spaces
    text = text.strip()
    print(text)

    # Convert text to lowercase
    text = text.lower()

    # Update the cleaned feedback
    feedback_data['Feedback'][i] = text

print("\nCleaned Feedbacks:")
print(feedback_data['Feedback'])

# Step 4: Word Count Insights

def count_word_in_feedbacks(word):
    count = 0

    for feedback in feedback_data['Feedback']:
        if word.lower() in feedback.lower().split():
            count += 1

    return count


# Print word count insights
print("Feedbacks containing 'good':",
      count_word_in_feedbacks("good"))

print("Feedbacks containing 'poor':",
      count_word_in_feedbacks("poor"))

print("Feedbacks containing 'excellent':",
      count_word_in_feedbacks("excellent"))
# Step 5: Final Summary & Insights

# 1. Display the final cleaned feedback_data
print("\n--- Final Cleaned Feedback Data ---")
print(feedback_data)


# 2. Calculate the average rating
total_rating = sum(feedback_data['Rating'])
total_feedbacks = len(feedback_data['Rating'])

if total_feedbacks > 0:
    average_rating = total_rating / total_feedbacks
    print("\nAverage Rating:", round(average_rating, 2))
else:
    print("\nNo feedbacks available to calculate average rating.")


# 3. Find the feedback with the longest comment
if feedback_data['Feedback']:
    longest_feedback = max(
        feedback_data['Feedback'],
        key=lambda feedback: len(feedback.split())
    )

    print("\n--- Longest Feedback ---")
    print("Comment:", longest_feedback)
    print("Word Count:", len(longest_feedback.split()))
else:
    print("\nNo feedback comments available.")


# 4. Find unique words across all feedbacks
unique_words = set()

for feedback in feedback_data['Feedback']:
    words = feedback.split()
    unique_words.update(words)

print("\n--- Unique Words ---")
print(sorted(unique_words))


# 5. Optional: Sort feedbacks by rating (highest to lowest)
sorted_feedbacks = sorted(
    zip(
        feedback_data['S_No'],
        feedback_data['Name'],
        feedback_data['Feedback'],
        feedback_data['Rating']
    ),
    key=lambda item: item[3],
    reverse=True
)

print("\n--- Feedbacks Sorted by Rating (Highest to Lowest) ---")

for s_no, name, feedback, rating in sorted_feedbacks:
    print(f"S.No: {s_no} | Name: {name} | "
          f"Rating: {rating} | Feedback: {feedback}")
